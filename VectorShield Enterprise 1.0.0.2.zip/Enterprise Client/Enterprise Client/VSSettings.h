#pragma once
#include "vectorshieldpropertiesconstants.h"
#include <vector>

template < class T >
class g_settings{
public:
	CString	field;
	T		setting;
	T get(void){
		return T;
	}
	void operator=(T t){ setting = t; }
};

class VSSettings{
public:
	VSSettings::VSSettings();
	/*g_settings<int> protect_field;
	g_settings<int> show_protection_field;
	g_settings<int> encryption_field;
	g_settings<int> use_tips_field;
	g_settings<int> windowropdelay_field;
	g_settings<int> usebackground_field;

	g_settings<char*>unprotected_download_path_field;
	g_settings<char*>hidden_folder_field[MAX_FOLDERS_OR_FILE_TYPES];
	g_settings<char*>hidden_file_type_field[MAX_FOLDERS_OR_FILE_TYPES];
	g_settings<char*>license;*/

	int	protect_field;
	bool show_protection_field;
	int	encryption_field;
	bool use_tips_field;
	int	windowropdelay_field;
	bool usebackground_field;
	char unprotected_download_path_field[100];
	//char hidden_folder_field[MAX_FOLDERS_OR_FILE_TYPES][100];
	//char hidden_file_type_field[MAX_FOLDERS_OR_FILE_TYPES][100];
	std::vector<CString> hidden_folder_field;//1.0.0.2
	std::vector<CString> hidden_file_type_field;//1.0.0.2
	char license[100];

	void set_protect_field(int);
	void set_show_protection_field(int);
	void set_encryption_field(int);
	void set_use_tips_field(int);
	void set_windowropdelay_field(int);
	void set_usebackground_field(int);
	void set_unprotected_download_path_field(CStringA);
	void set_hidden_folder_field(CStringA);
	void set_hidden_file_type_field(CStringA);
	void set_license(CStringA);

	int get_protect_field(void);
	int get_show_protection_field(void);
	int get_encryption_field(void);
	int get_use_tips_field(void);
	int get_windowropdelay_field(void);
	int get_usebackground_field(void);
	CString get_unprotected_download_path_field(void);
	CString get_hidden_folder_field(int);
	CString get_hidden_file_type_field(int);
	CString get_license(void);
	
	void reset_hidden_folder_field(void);
	void reset_hidden_file_type_field(void);
		
	HANDLE lock_mutex;
	void init_settings(void);
	void lock();
	void release();
	void set(VSSettings value);
	VSSettings get();

};