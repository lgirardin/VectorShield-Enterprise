#include "stdafx.h"
#include "constants.h"
#include "resource.h"
#include "communication.h"
#include "Connector.h"
#include "Enterprise ClientDlg.h"

CEnterpriseClientDlg* TheClient;


int CALLBACK Dspl_message(CString& str){
	TheClient->Msg = str;
	PostMessage(TheClient->m_hWnd, DSPL_MSG, 0, 0);
	return 0;
}

int CALLBACK GetSettings(void){
	TheClient->get_settings();
	return 0;
}

int CALLBACK SetValue(Comm& data){
	TheClient->set_value(data);
	return 0;
}

int CALLBACK GetValue(Comm& data){
	TheClient->get_value(data);
	return 0;
}

int CALLBACK SetValue2(CString& data){
	TheClient->set_value(data);
	return 0;
}

int CALLBACK GetValue2(CString& data){
	CString str;
	TheClient->get_value(data,true,str);
	return 0;
}



int CALLBACK SetSettings(Comm& data){
	TheClient->set_settings(data);
	return 0;
}

int CALLBACK GetLog(void){
	TheClient->get_logs();
	return 0;
}


int CALLBACK IsLoggedIn(bool logged){
	TheClient->isloggedIn(logged);
	return 0;
}

void Connector::setTheClient(void){
	TheClient = main;
}

void Connector::connect(void){
	if (ConnectToService) (ConnectToService)();
}

Connector::Connector()
{
	HINSTANCE Lib = LoadLibrary(_T("c:\\Enterprise\\Connector.dll"));

	if (Lib != NULL){

		SendResponse = (VSHIELDSENDREQUEST)GetProcAddress(Lib, "SendResponse");
		SendResponse2 = (VSHIELDSENDREQUEST2)GetProcAddress(Lib, "SendResponse2");

		ConnectToService = (CONNECT)GetProcAddress(Lib, "ConnectToService");
		SetDataType = (SETDATATYPE)GetProcAddress(Lib, "SetDataType");


		SetDsplCallbackNotif = (ADDR)GetProcAddress(Lib, "SetDsplCallbackNotif");
		if (SetDsplCallbackNotif)
			(SetDsplCallbackNotif)((DWORD_PTR)&Dspl_message);

		SetGetCallbackSettingsNotif = (ADDR)GetProcAddress(Lib, "SetGetCallbackSettingsNotif");
		if (SetGetCallbackSettingsNotif)
			(SetGetCallbackSettingsNotif)((DWORD_PTR)&GetSettings);

		SetSetSettingsCallbackNotif = (ADDR)GetProcAddress(Lib, "SetSetSettingsCallbackNotif");
		if (SetSetSettingsCallbackNotif)
			(SetSetSettingsCallbackNotif)((DWORD_PTR)&SetSettings);

		SetGetLogCallBackNotif = (ADDR)GetProcAddress(Lib, "SetGetLogCallBackNotif");
		if (SetGetLogCallBackNotif)
			(SetGetLogCallBackNotif)((DWORD_PTR)&GetLog);

		SetIsLoggedInCalledBackNotif = (ADDR)GetProcAddress(Lib, "SetIsLoggedInCalledBackNotif");
		if (SetIsLoggedInCalledBackNotif)
			(SetIsLoggedInCalledBackNotif)((DWORD_PTR)&IsLoggedIn);

		SetSetValueCallbackNotif = (ADDR)GetProcAddress(Lib, "SetSetValueCallbackNotif");
		if (SetSetValueCallbackNotif)
			(SetSetValueCallbackNotif)((DWORD_PTR)&SetValue);
	
		SetGetValueCallbackNotif = (ADDR)GetProcAddress(Lib, "SetGetValueCallbackNotif");
		if (SetGetValueCallbackNotif)
			(SetGetValueCallbackNotif)((DWORD_PTR)&GetValue);

		SetSetValueCallbackNotif2 = (ADDR)GetProcAddress(Lib, "SetSetValueCallbackNotif2");
		if (SetSetValueCallbackNotif2)
			(SetSetValueCallbackNotif2)((DWORD_PTR)&SetValue2);

		SetGetValueCallbackNotif2 = (ADDR)GetProcAddress(Lib, "SetGetValueCallbackNotif2");
		if (SetGetValueCallbackNotif2)
			(SetGetValueCallbackNotif2)((DWORD_PTR)&GetValue2);

	}
}

Connector::~Connector()
{
}
