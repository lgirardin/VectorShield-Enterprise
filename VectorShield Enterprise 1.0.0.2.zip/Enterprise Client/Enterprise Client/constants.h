#pragma once

#define COMM_DATA_SIZE 1400
#define VS_VERSION_RESPONSE 'V'
#define GET_LOGS 'L'
#define DSPL_MSG 3001

#define RECEIVE_SETTINGS 'S'
#define RECEIVE_LOGS 'L'
#define SET_VALUE_REQUEST 'w'


#define ENDVALUE_SEP ';'
#define ASSIGNMENT_SEP '='

#define MAX_FOLDERS_OR_FILE_TYPES 5



enum DSPL_MSG_TYPES
{
	HB_KILLED_SERVER_NOT_RESPONDING = 0,
	HB_KILLED_REQUEST_BY_SERVER = 1
};

#define FIXED_SZ_DATA 0//1.0.0.2
#define VARIABLE_SZ_DATA 1//1.0.0.2

