
#include "stdafx.h"
#include "constants.h"
#include "vectorshieldpropertiesconstants.h"
#include "VSSettings.h"

VSSettings::VSSettings(void){
	lock_mutex = CreateMutex(NULL, false, _T("lock_mutex"));
	init_settings();

}

/*init_settings reads the values from a db or a registry key and initializes the value for the settings being used by
vector shield*/
void VSSettings::init_settings(void){

	//fill out data into tmp - should be read from persistant storage (registry or some form of db)
	encryption_field = ENCRYPTION_STRONG_RADIO;
	protect_field = PROTECT_DISABLE_RADIO;
	usebackground_field = FEATURE_OFF;
	use_tips_field = FEATURE_ON;
	windowropdelay_field = 5;
	strcpy(unprotected_download_path_field, "c:\\enterprise2");
	show_protection_field = FEATURE_ON;
	/*for (int y = 0; y < MAX_FOLDERS_OR_FILE_TYPES; y++){
		hidden_folder_field[y][0] = hidden_file_type_field[y][0] = (char)0;
	}

	strcpy(hidden_file_type_field[0], ".xls2");
	strcpy(hidden_file_type_field[1], ".docx2");
	hidden_file_type_field[2][0] = (char)0;
	strcpy(hidden_folder_field[0], "c:\\hiddenfolder2");
	hidden_folder_field[1][0] = (char)0;*/
	hidden_folder_field.push_back(_T("c:\\hiddenfolder2"));
	hidden_file_type_field.push_back(_T(".xls2"));
	hidden_file_type_field.push_back(_T(".docx2"));
	strcpy(license, "LICENSE1234-5678-1234-5678");

}

void VSSettings::lock(void){

	WaitForSingleObject(lock_mutex, INFINITE);
}

void VSSettings::release(void){

	ReleaseMutex(lock_mutex);
}

void VSSettings::set(VSSettings value){

	lock();
	*this = value;
	release();
}

VSSettings VSSettings::get(){
	lock();
	return *this;
	release();
}

void VSSettings::set_protect_field(int val){
	lock();
	protect_field = val;
	release();
}

void VSSettings::set_show_protection_field(int val){
	lock();
	show_protection_field = val;
	release();

}
void VSSettings::set_encryption_field(int val){
	lock();
	encryption_field = val;
	release();

}
void VSSettings::set_use_tips_field(int val){
	lock();
	use_tips_field = val;
	release();

}
void VSSettings::set_windowropdelay_field(int val){
	lock();
	windowropdelay_field = val;
	release();

}
void VSSettings::set_usebackground_field(int val){
	lock();
	usebackground_field = val;
	release();

}
void VSSettings::set_unprotected_download_path_field(CStringA val){
	lock();
	memcpy((void*)&unprotected_download_path_field, val, val.GetLength());
	unprotected_download_path_field[val.GetLength()] = (char)0;
	release();
}
void VSSettings::set_hidden_folder_field(CStringA val){
	lock();
	/*for (int y = 0; y < MAX_FOLDERS_OR_FILE_TYPES; y++){
		if (hidden_folder_field[y][0] == (char)0){
			memcpy((void*)&hidden_folder_field[y], val, val.GetLength());
			hidden_folder_field[y][val.GetLength()] = (char)0;
			break;
		}
	}*/
	hidden_folder_field.push_back((CString)val);
	release();
}

void VSSettings::set_hidden_file_type_field(CStringA val){
	lock();
	/*for (int y = 0; y < MAX_FOLDERS_OR_FILE_TYPES; y++){
		if (hidden_file_type_field[y][0] == (char)0){
			memcpy((void*)&hidden_file_type_field[y], val, val.GetLength());
			hidden_file_type_field[y][val.GetLength()] = (char)0;
			break;
		}
	}*/
	hidden_file_type_field.push_back((CString)val);
	release();

}
void VSSettings::set_license(CStringA val){
	lock();
	memcpy((void*)&license[0], val, val.GetLength());
	license[val.GetLength()] = (char)0;
	release();
}




int VSSettings::get_protect_field(void){
	lock();
	int val = protect_field;
	release();
	return val;

}
int VSSettings::get_show_protection_field(void){
	lock();
	int val = show_protection_field;
	release();
	return val;

}
int VSSettings::get_encryption_field(void){
	lock();
	int val = encryption_field;
	release();
	return val;

}
int VSSettings::get_use_tips_field(void){
	lock();
	int val = use_tips_field;
	release();
	return val;
}
int VSSettings::get_windowropdelay_field(void){
	lock();
	int val = windowropdelay_field;
	release();
	return val;
}
int VSSettings::get_usebackground_field(void){
	lock();
	int val = usebackground_field;
	release();
	return val;
}

CString VSSettings::get_unprotected_download_path_field(void){
	lock();
	CString val = (CString)unprotected_download_path_field;
	release();
	return val;
}

CString VSSettings::get_hidden_folder_field(int index){
	lock();
	//CString val = (CString)hidden_folder_field[index];//1.0.0.2 out
	CString val = hidden_folder_field.at(index);//1.0.0.2 
	release();
	return val;
}

CString VSSettings::get_hidden_file_type_field(int index){
	lock();
	//CString val = (CString)hidden_file_type_field[index];	//1.0.0.2 out
	CString val = hidden_file_type_field.at(index);//1.0.0.2

	release();
	return val;
}

CString VSSettings::get_license(void){
	lock();
	CString val = (CString)license;
	release();
	return val;
}

void VSSettings::reset_hidden_folder_field(void){
	lock();
	//for (int u = 0; u<MAX_FOLDERS_OR_FILE_TYPES; u++) hidden_folder_field[u][0] = (char)0;
	hidden_folder_field.clear();
	release();
}

void VSSettings::reset_hidden_file_type_field(void){
	lock();
	//for (int u = 0; u<MAX_FOLDERS_OR_FILE_TYPES; u++) hidden_file_type_field[u][0] = (char)0;
	hidden_file_type_field.clear();
	release();
}

