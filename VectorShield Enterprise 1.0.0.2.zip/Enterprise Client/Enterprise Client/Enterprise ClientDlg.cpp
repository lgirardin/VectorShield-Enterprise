
// Enterprise ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "constants.h"
#include "communication.h"
#include "Enterprise Client.h"
#include "Enterprise ClientDlg.h"
#include "afxdialogex.h"
#include "vectorshieldpropertiesconstants.h"

std::string FIELD_LIST[FIELD_COUNT] = { REG_ASK_ATTR, REG_SHOW_DIALOG_ATTR, REG_ENCRYPT_ATTER, REG_SHOW_TIPS_ATTR, REG_DROP_DELAY_ATTR, REG_SHOW_BACKGROUND_ATTR, REG_DOWNLOAD_DIR_VAL, REG_PROTECT_DIR_VAL, REG_PROTECT_TYPES_VAL, REG_LICENSE_NO_ATTER };


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

// CEnterpriseClientDlg dialog


CEnterpriseClientDlg::CEnterpriseClientDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CEnterpriseClientDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);


}

void CEnterpriseClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_output);
}

BEGIN_MESSAGE_MAP(CEnterpriseClientDlg, CDialogEx)
	ON_MESSAGE(DSPL_MSG,ondspl)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
END_MESSAGE_MAP()

// CEnterpriseClientDlg message handlers



void CEnterpriseClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEnterpriseClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEnterpriseClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


BOOL CEnterpriseClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	/**********ALL THAT IS NEEDED TO INVOKE THE CONNECTOR IS AFTER THIS LINE*******/
	settings = new VSSettings;
	m_logged_in = false;

	aConnector = new(Connector);
	aConnector->main = this;
	aConnector->SetDataType(VARIABLE_SZ_DATA);
	aConnector->DataType = VARIABLE_SZ_DATA;//1.0.0.2
	aConnector->setTheClient();
	aConnector->connect();

	return TRUE;  // return TRUE  unless you set the focus to a control
}



/*Get_setting gets called by the management console when the value of all settings is asked
The client provides here the current value for all settings to send it to the management console*/
void CEnterpriseClientDlg::get_settings(void){
	CString str;
	str = _T("Received request to provide Vector Shield Settings");
	m_output.InsertString(0, str);

	//either provide them a a bulk or one by one
	//if there are more than 5 hidden file types or more than 5 hidden folders
	//us the set_value for each additional value after 5

	if (aConnector->DataType == FIXED_SZ_DATA){//1.0.0.2
		//copy into Comm structure
		Comm data;
		data.filler[0] = RECEIVE_SETTINGS;
		memcpy((void*)&data.filler[1], &settings->get(), sizeof(VSSettings));

		//send it to Enterprise console
		(aConnector->SendResponse)(data);
	}
	else{
		CString fd; fd.Format(_T("%c"), ' ');//first digit is unknown
		CString data;
		CString tosend;

		for (int y = 0; y < FIELD_COUNT; y++){
			data = fd;
			data += FIELD_LIST[y].c_str();;
			get_value(data,false,tosend);//we batch the strings together to send them in one message
		}
		//we send tosend out
		CString outdata; outdata.Format(_T("%c"), RECEIVE_SETTINGS);
		outdata += tosend;
		(aConnector->SendResponse2)(NULL, outdata);
	}
}

/*Set_settings gets called by the management console when the settings as a whole should be replaced with 
the one provided in the message. You may need to mutex protect the settings if other processes may be ready from it at the 
same time*/

void CEnterpriseClientDlg::set_settings(Comm& data){
	CString str;
	str = _T("Received request to overwrite my own settings with the ones provided");
	m_output.InsertString(0, str);
	VSSettings tmp;
	memcpy(&tmp, (const void*)&data.filler[1], sizeof(VSSettings));
	settings->set(tmp);
}

/*Set_value is called by the management console to have the vector shield overwrite one of the setting with a new value:
The format is FIELD=VALUE; Right now we support only one pair (Field, value) of parameter.
If the FIELD is HIDDEN_FOLDER_RESET_FIELD (resp. HIDDEN_FILE_TYPE_RESET_FIELD) then the client should reset its list of 
hidden follders (resp. list of hidden file types), as the console is likely to send a new list of folders (resp. file types) as a replacement*/

void CEnterpriseClientDlg::set_value(CString& data){//1.0.0.2

	CStringA str(data.Right(data.GetLength()-1));
	process_set_value(str);
}


void CEnterpriseClientDlg::set_value(Comm& data){
	CStringA str((char*)&data.filler[1]);

	process_set_value(str);
}

void CEnterpriseClientDlg::process_set_value(CStringA str){//1.0.0.2

	CStringA getvalue, setvalue;

	int sep = str.Find(ASSIGNMENT_SEP);
	if (sep != -1){
		getvalue = str.Left(sep);
		int end = str.Find(ENDVALUE_SEP);
		if (-1 == end)
			end = str.GetLength();
		setvalue = str.Mid(sep + 1, end - sep - 1);
	}

	str = _T("Received request to overwrite ");
	str += getvalue; str += _T(" with");
	str += setvalue;
	m_output.InsertString(0, (CString)str);

	if (getvalue == HIDDEN_FOLDER_RESET_FIELD){//console about to send list of hidden folders, asking to reset our own list
		settings->reset_hidden_folder_field();
		// RESET our hidden folders list
	}
	else if (getvalue == HIDDEN_FILE_TYPE_RESET_FIELD)//console about to send list of hidden file types, asking to reset our own list
	{
		//RESET our hidden file types list
		settings->reset_hidden_file_type_field();
	}
	else{
		//let's read what value needs to be updated
		if (getvalue == REG_ASK_ATTR){
			settings->set_protect_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_SHOW_DIALOG_ATTR){
			settings->set_show_protection_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_ENCRYPT_ATTER){
			settings->set_encryption_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_SHOW_TIPS_ATTR){
			settings->set_use_tips_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_DROP_DELAY_ATTR){
			settings->set_windowropdelay_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_SHOW_BACKGROUND_ATTR){
			settings->set_usebackground_field(_ttoi((CString)setvalue));
		}
		else if (getvalue == REG_DOWNLOAD_DIR_VAL){
			settings->set_unprotected_download_path_field(setvalue);
		}
		else if (getvalue == REG_PROTECT_DIR_VAL){
			settings->set_hidden_folder_field(setvalue);
		}
		else if (getvalue == REG_PROTECT_TYPES_VAL){
			settings->set_hidden_file_type_field(setvalue);
		}
		else if (getvalue == REG_LICENSE_NO_ATTER){
			settings->set_license(setvalue);
		}
	}

}

/*The management console sends this message to request the value for a specific setting (FIELD)
The format is FIELD;
VectorShiled should return the value for the field using the following format:
SET_VALUE_REQUEST FIELD=VALUE
For Fields of type HIDDEN_FOLDER_FIELD (resp. HIDDEN_FILE_TYPE_FIELD), vector shields needs here to send as many messages as it has folders 
(resp. file types), reitering though them
*/

void CEnterpriseClientDlg::get_value(CString& data,bool send, CString& tosend){//1.0.0.2
	CStringA str(data.Right(data.GetLength()-1));
	process_get_value(str,send,tosend);
}


void CEnterpriseClientDlg::get_value(Comm& data){
	CString tosend;//1.0.0.2
	CStringA str((char*)&data.filler[1]);
	process_get_value(str,true,tosend);
}

void CEnterpriseClientDlg::process_get_value(CStringA  str, bool send, CString& tosend){

	CStringA getvalue;

	CString val;

	int end = str.Find(ENDVALUE_SEP);
	if (-1 == end)
		end = str.GetLength();
	getvalue = str.Left(end);

	str = "Received request to provide value for ";
	str += getvalue;

	m_output.InsertString(0, (CString)str);

	//let's send value for that field to the console
	Comm outdata;
	outdata.filler[0] = SET_VALUE_REQUEST;
	str = getvalue;
	str += ASSIGNMENT_SEP;
	CStringA cpy(str);

	if (getvalue == REG_PROTECT_DIR_VAL){
		//PROVIDE HERE THE PATH FOR EITHER HIDDEN FOLDERS OR HIDDEN FILE TYPES and send them one by one to Console
		//for (int c = 0; c < MAX_FOLDERS_OR_FILE_TYPES; c++){//1.0.0.2 out
		int c(0);
		for (auto iter = settings->hidden_folder_field.begin(); iter != settings->hidden_folder_field.end(); iter++){
			CString tmp = settings->get_hidden_folder_field(c++);
			if (tmp.GetLength()>0){
				val = tmp;
				cpy += val;
				cpy += ENDVALUE_SEP;
				if (send){
					if (aConnector->DataType == FIXED_SZ_DATA){//1.0.0.2
						memcpy((char*)&outdata.filler[1], cpy, cpy.GetLength());
						outdata.filler[cpy.GetLength() + 1] = (char)0;
						(aConnector->SendResponse)(outdata);
					}
					else{
						CString data; data.Format(_T("%c"), SET_VALUE_REQUEST);
						data += cpy;
						(aConnector->SendResponse2)(NULL, data);
					}
				}
				else tosend += cpy;
				cpy = str;
			}
		}
	}
	else if (getvalue == REG_PROTECT_TYPES_VAL){
		//for (int c = 0; c < MAX_FOLDERS_OR_FILE_TYPES; c++){
		int c(0);
		for (auto iter = settings->hidden_file_type_field.begin(); iter != settings->hidden_file_type_field.end();iter++){
			CString tmp = settings->get_hidden_file_type_field(c++);
			if (tmp.GetLength()>0){
				val = tmp;
				cpy += val;
				cpy += ENDVALUE_SEP;
				if (send){
					if (aConnector->DataType == FIXED_SZ_DATA){//1.0.0.2
						memcpy((char*)&outdata.filler[1], cpy, cpy.GetLength());
						outdata.filler[cpy.GetLength() + 1] = (char)0;
						(aConnector->SendResponse)(outdata);
					}
					else{
						CString data; data.Format(_T("%c"), SET_VALUE_REQUEST);
						data += cpy;
						(aConnector->SendResponse2)(NULL, data);
					}
				}
				else tosend += cpy;
				cpy = str;
			}
		}
	}
	else{
	
		if (getvalue == REG_ASK_ATTR){
			val.Format(_T("%i"), settings->get_protect_field());
			str += val;
		}
		else if (getvalue == REG_SHOW_DIALOG_ATTR){
			val.Format(_T("%i"), settings->get_show_protection_field());
			str += val;
		}
		else if (getvalue == REG_ENCRYPT_ATTER){
			val.Format(_T("%i"), settings->get_encryption_field());
			str += val;
		}
		else if (getvalue == REG_SHOW_TIPS_ATTR){
			val.Format(_T("%i"), settings->get_use_tips_field());
			str += val;
		}
		else if (getvalue == REG_DROP_DELAY_ATTR){
			val.Format(_T("%i"), settings->get_windowropdelay_field());
			str += val;
		}
		else if (getvalue == REG_SHOW_BACKGROUND_ATTR){
			val.Format(_T("%i"), settings->get_usebackground_field());
			str += val;
		}
		else if (getvalue == REG_DOWNLOAD_DIR_VAL){
			val = settings->get_unprotected_download_path_field();
			str += val;
		}
		else if (getvalue == REG_LICENSE_NO_ATTER){
			val = settings->get_license();
			str += val;
		}	

		//PROVIDE HERE THE VALUE FOR THE FIELD REQUESTED
		str += ENDVALUE_SEP;

		if (send){

			if (aConnector->DataType == FIXED_SZ_DATA){//1.0.0.2

				memcpy((char*)&outdata.filler[1], str, str.GetLength());
				outdata.filler[str.GetLength() + 1] = (char)0;
				(aConnector->SendResponse)(outdata);
			}
			else{//1.0.0.2
				CString data; data.Format(_T("%c"), SET_VALUE_REQUEST);
				data += str;
				(aConnector->SendResponse2)(NULL, data);
			}
		}
		else tosend += str;
	}

}

/*isloggedIn is called when the client is successfully able to connect to IP address laid in maconsoleip file and port 3500.
We will add a range of ports in the next release
The possible thing that could happen here is to send a message back to the management console providing the VectorShield or OS version and built*/

void CEnterpriseClientDlg::isloggedIn(bool logged){

	if (logged &&!m_logged_in){
		if (aConnector->DataType == FIXED_SZ_DATA){
			if (aConnector->SendResponse){
				Comm data;
				data.filler[0] = VS_VERSION_RESPONSE;
				const char* vs = "VS 1.0.20";
				memcpy((void*)&data.filler[1], vs, 9);
				(aConnector->SendResponse)(data);
			}
		}
		else{
			if (aConnector->SendResponse2){
				CString str; 
				str.Format(_T("%cVS 1.0.20"), VS_VERSION_RESPONSE);
				(aConnector->SendResponse2)(NULL,str);
			}
		}
	}

	m_logged_in = logged;
}

/*ondspl is called whenever a network layer message (such as logged in, logged out, force logged out, lossed connection) needs to be communicated.
right now we display a message. Please note when a connection loss or disconnect is trigered, the connector product
manages the sourse of action already, typically trying to log back in automatically*/

LRESULT CEnterpriseClientDlg::ondspl(WPARAM wparam, LPARAM lparam){
	//let's signal the HP server to shut down
	CString tmp;
	m_output.InsertString(0, Msg);
	return 0;
}

/*This message from the management console is a request for logs to be sent over. Logs may be sent in chunks of 1400 bytes back to the console*/

void CEnterpriseClientDlg::get_logs(void){
	CString str;
	str = _T("Received request to provide Vector Shield Logs");
	m_output.InsertString(0, str);

	Comm data;
	data.filler[0] = RECEIVE_LOGS;
	(aConnector->SendResponse)(data);
}