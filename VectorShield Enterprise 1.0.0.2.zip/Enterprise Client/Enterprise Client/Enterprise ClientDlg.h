
// Enterprise ClientDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "communication.h"
#include "Connector.h"
#include "VSSettings.h"

// CEnterpriseClientDlg dialog
class CEnterpriseClientDlg : public CDialogEx
{
// Construction
public:
	CEnterpriseClientDlg(CWnd* pParent = NULL);	// standard constructor
	CString Msg;

	void get_settings(void);
	void set_settings(Comm& data);
	void set_value(Comm& data);
	void get_value(Comm& data);
	void set_value(CString& data);
	void get_value(CString& data, bool send, CString& tosend);//1.0.0.2 added , bool send, CString& tosend
	void process_set_value(CStringA str);//1.0.0.2
	void process_get_value(CStringA  str, bool send, CString& tosend);//1.0.0.2

	void get_logs(void);
	void isloggedIn(bool logged);
	//void init_settings(void);

	bool m_logged_in;

	VSSettings* settings;

	Connector*  aConnector;


// Dialog Data
	enum { IDD = IDD_ENTERPRISECLIENT_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg LRESULT ondspl(WPARAM wparam, LPARAM lparam);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CListBox m_output;
};
