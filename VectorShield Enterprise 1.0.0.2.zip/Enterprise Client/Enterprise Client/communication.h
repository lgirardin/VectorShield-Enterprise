#pragma once
class Comm{
public:
	BYTE filler[COMM_DATA_SIZE];
};