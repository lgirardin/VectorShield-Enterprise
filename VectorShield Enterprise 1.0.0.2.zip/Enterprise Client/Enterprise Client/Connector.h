#pragma once

typedef void(__cdecl *ADDR)(DWORD_PTR);
typedef void(__cdecl *VSHIELDSENDREQUEST)(Comm &data);
typedef void(__cdecl *CONNECT)(void);
typedef void(__cdecl *SETDATATYPE)(int);//1.0.0.2
typedef int(__cdecl *VSHIELDSENDREQUEST2)(SOCKET sock,CString data);//1.0.0.2


class CEnterpriseClientDlg;
class Connector
{
public:
	Connector();
	~Connector();
	CEnterpriseClientDlg* main;
	void setTheClient(void);
	void connect(void);

	ADDR SetDsplCallbackNotif;
	ADDR SetGetCallbackSettingsNotif;
	ADDR SetSetSettingsCallbackNotif;
	ADDR SetGetLogCallBackNotif;
	ADDR SetIsLoggedInCalledBackNotif;
	ADDR SetSetValueCallbackNotif;
	ADDR SetGetValueCallbackNotif;
	ADDR SetSetValueCallbackNotif2;//1.0.0.2
	ADDR SetGetValueCallbackNotif2;//1.0.0.2

	VSHIELDSENDREQUEST SendResponse;
	VSHIELDSENDREQUEST2 SendResponse2;//1.0.0.2
	CONNECT ConnectToService;
	SETDATATYPE SetDataType;//1.0.0.2
	int DataType;//1.0.0.2

};

